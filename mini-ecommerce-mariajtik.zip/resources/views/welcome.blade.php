@extends('layouts.app')

@section('content')
<h1 class="text-2xl font-bold mb-4">Produtos</h1>

@livewire('product-list')
@endsection

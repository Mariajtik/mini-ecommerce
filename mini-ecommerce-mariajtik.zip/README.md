# Mini E-commerce (Laravel + Livewire) - Template
Author: mariajtik

## Descrição
Template inicial para o desafio técnico "Mini E-commerce (Laravel + Livewire)".

## Conteúdo
- Dockerfile, docker-compose.yml
- .env.example
- Estrutura de diretórios com modelos, migrations, factories, seeders
- Componentes Livewire esqueléticos
- Views Blade com TailwindCSS (esqueleto)
- Composer e package.json com dependências básicas

## Como usar (local)
1. Copie para o seu ambiente de desenvolvimento (ou baixe e extraia).
2. Ajuste `.env` baseado em `.env.example`.
3. Rode `composer install` e `npm install && npm run dev`.
4. Rode `php artisan migrate --seed`.
5. Rode `php artisan serve` ou use o docker-compose.

## Docker
```bash
docker-compose up -d
docker-compose exec app bash
composer install
php artisan key:generate
php artisan migrate --seed
```

## Credenciais de teste
- Email: user@example.com
- Senha: password


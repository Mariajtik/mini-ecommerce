<?php
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

// Product detail route
Route::get('/product/{product}', [App\Http\Controllers\ProductController::class, 'show'])->name('product.show');

// Auth routes (Breeze) - placeholder
require __DIR__.'/auth.php';
